# Enemy HUD names

Names were matched to the illustrations on pages 28–29 of the [original Japanese manual](https://emubox.net/resources/GAME/213/OHqCH7qA.pdf), using the [English manual translation](https://gamefaqs.gamespot.com/genesis/586215-golden-axe-iii/faqs/51321) as a romanization reference. Japanese names admit different English spellings; this patch uses **Ego Il Sheep** and **Damned Hellstrike**.

| ROM family | HUD base name | Identification |
| --- | --- | --- |
| 1 | Eve | Winged boss; manual p. 29 |
| 5 | Rancor | Common male soldier; patch-authored name, omitted from manual roster |
| 6 | Havoc | Stocky club wielder; patch-authored name, omitted from manual roster |
| 7 | Ego Il Sheep | Four-armed demon; manual p. 28 |
| 8 | Mustang | Giant with polearm; manual p. 29 |
| 9 | Vanity | Female soldier; manual p. 28 |
| 10 | Corvette | Armored commander; manual p. 28 |
| 11, 14 | Dead Frame | Skeletal warrior; manual p. 28 |
| 12, 13 | Damned Hellstrike | Final boss, both combat forms; manual p. 29 |
| 0, 2, 3, 4 | Cursed Proud / Kain / Chronos / Sarah | Hero families encountered as opponents |

Variant adjectives are original additions for this patch, **not official manual names**. The actor's `$82` version byte selects the adjective, independently of its hardware palette slot. Version zero keeps the base name. Versions 1–7 use Fierce, Dire, Dark, Elite, Royal, Dread, and Vile. These are flavor names, not claims about numerical difficulty ranks.

For Ego Il Sheep, the corresponding adjectives are Fell, Dire, Dark, Grim, Wild, Vile, and Elite so the complete name fits. The unique final boss retains his full name in both forms. Hero opponents use Cursed followed by their first name.

All labels fit within the 64-pixel field with a one-pixel left and top inset, without truncation or scrolling. Word spaces are two pixels including letter spacing. Names are authored as strings with a shared proportional 3×5 uppercase font in [enemy_names.py](tools/enemy_names.py). The builder generates name tiles independently of HP graphics; the game selects and combines them in its existing three-sprite enemy panel. This is a fixed enemy-name system, not a general-purpose runtime text engine.

Emulator verification covers all 120 family/version lookup combinations, clipping checks during asset generation, independent variant capture, preservation of the name on defeat, and unchanged HP graphics.
