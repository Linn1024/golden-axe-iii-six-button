Golden Axe III - Six-Button Controls & Enemy HUD
Version 1.0
Platform: Sega Genesis / Mega Drive

INSTALLATION
Apply Golden_Axe_III_6Button_EnemyHUD.ips to your own copy of the exact
source ROM identified below, using an IPS patcher. Start the resulting
ROM from a fresh boot and select a six-button Genesis controller.
This package contains a patch, not a playable ROM.
Compatibility with other dumps or other hacks has not been verified.
The tested source is the [h1] dump, not a verified clean retail dump.

DEFAULT CONTROLS
X (hold): Block
Y: Round Attack
Z: Character Unique Move
Both players are supported. ABC actions retain their separate layouts.
Options > XYZ CONTROL cycles all six assignments with Left/Right.
Options > 3PAD COMBOS defaults to OFF on both controller types.
Turn it ON to restore the original block, round-attack and directional
unique-move combinations, including when using a three-button pad.
Settings survive a soft reset; a fresh launch uses the defaults.

ENEMY HUD
A centered panel shows the last damaged enemy's portrait, name and HP.
Names follow the manual where listed, with original variant adjectives.
Rancor and Havoc are original names for grunts omitted from that roster.
Eve uses an upright animation frame for the portrait.
Regular-game player HUDs leave room for maximum health and the panel.
Versus retains the original player HUD positions.

LEVEL SELECT
Press A+B+C together on controller 1 at character selection.
Use Up/Down to choose a stage, then Start to begin.

VALIDATION
Emulator regression checks cover controls, options, rendered labels,
enemy HUD updates, expanded life bars and Versus HUD positions.
IPS reconstruction and the Genesis checksum have been verified.
Physical hardware and a complete campaign playthrough were not tested.
Old ROM save states are not supported as an installation method.

ROM IDENTIFICATION
Source filename: Golden_Axe_III_(J)_[h1].bin
Source size: 1048576
Source CRC32: 65F4D556
Source MD5: 8f3f887d86cca2d586e5e6515121b0df
Source SHA-1: a602f49de6f006b9cd210049496098dc01a1ca10
Source SHA-256: 04d753b8e24ba7644091eb662f93dfaa4d5124c6c69b31fc5c1682ad68c665f6
Patched SHA-256: 591f1c692262f376adb5ed7451ba273a343b459fcf9645e1e9c95d513f4bceeb
